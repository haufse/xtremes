API
===

.. autosummary::
   :toctree: generated

   test_xtremes
