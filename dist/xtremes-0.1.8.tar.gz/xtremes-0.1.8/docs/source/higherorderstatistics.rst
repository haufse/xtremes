Tutorial: Higher Order Statistics
=================================

This module is a specialized on analyzing the influence of higher order statistics for Maximum Likelihood estimations. 


Tutorial to be written...