[![Readthedocs Status](https://readthedocs.org/projects/xtremes/badge/?version=latest)](https://xtremes.readthedocs.io/en/latest/)


Welcome to xtremes!
===================

**xtremes** is a Python library for various utilities useful in Extreme Value Statistics. It is created within the ClimXtreme project 
and will provide supplementary code and simulations for the papers yet to come.

Check out <https://test.pypi.org/project/test-xtremes/> for installation and <https://xtremes.readthedocs.io/en/latest/> for further information!

Note:
-----
   This project is under active & heavy development.
