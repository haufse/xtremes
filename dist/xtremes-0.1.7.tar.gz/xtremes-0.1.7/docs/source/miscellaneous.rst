Tutorial: Miscellaneous
=======================

This module is a collection for non-specialized, frequently used or basic functions. 

Tutorial to be written...