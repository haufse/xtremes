Tutorial: Bootstrap
=================================

This module computes a Bootstrap procedure on disjoint or sliding block maxima. 


Tutorial to be written...